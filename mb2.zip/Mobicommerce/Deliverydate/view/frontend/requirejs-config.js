var config = {
    "map": {
        "*": {
            "Magento_Checkout/js/model/shipping-save-processor/default" : "Mobicommerce_Deliverydate/js/shipping-save-processor/default-override"
        }
    }
};