<?php
/**
 * @author Mobicommerce Team
 * @copyright Copyright (c) 2018 Mobicommerce (https://www.mobicommerce.com)
 * @package Mobicommerce_Mobiadmin3
 */

namespace Mobicommerce\Mobiadmin3\Observer;

use Magento\Framework\Event\ObserverInterface;

class Storeadd implements ObserverInterface
{
    protected $_storeManager;

    /**
     * @var \Mobicommerce\Mobiadmin3\Model\AppsettingFactory
     */
    protected $_mobiadmin3AppsettingFactory;

    /**
     * @var \Mobicommerce\Mobiadmin3\Model\Resource\Appsetting\CollectionFactory
     */
    protected $_mobiadmin3ResourceAppsettingCollectionFactory;

    protected $_mobiadmin3Applications;

    protected $_categoryRepository;

    public function __construct(
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Mobicommerce\Mobiadmin3\Model\AppsettingFactory $mobiadmin3AppsettingFactory,
        \Mobicommerce\Mobiadmin3\Model\Resource\Appsetting\CollectionFactory $mobiadmin3ResourceAppsettingCollectionFactory,
        \Mobicommerce\Mobiadmin3\Model\Applications $mobiadmin3Applications,
        \Magento\Catalog\Model\CategoryRepository $categoryRepository
    ) {
        $this->_storeManager = $storeManager;
        $this->_mobiadmin3AppsettingFactory = $mobiadmin3AppsettingFactory;
        $this->_mobiadmin3ResourceAppsettingCollectionFactory = $mobiadmin3ResourceAppsettingCollectionFactory;
        $this->_mobiadmin3Applications = $mobiadmin3Applications;
        $this->_categoryRepository = $categoryRepository;
    }

    /**
     * When adding new store, it will insert settings for cms_settings,homepage_categories
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $store = $observer->getStore()->getId();
        if(!empty($store)){
            $settings = ["cms_settings", "homepage_categories"];
            foreach($settings as $_setting){
                $collection = $this->_mobiadmin3ResourceAppsettingCollectionFactory->create()->addFieldToFilter('setting_code', $_setting);

                $collection->getSelect()->group('app_code');
                if($collection->getSize()){
                    foreach($collection as $_collection){
                        $data = $_collection->getData();
                        $_value = $data['value'];

                        if($_setting == 'homepage_categories') {
                            $root_category_id = $this->_storeManager->getStore($store)->getRootCategoryId();
                            $categoryObj = $this->_categoryRepository->get($root_category_id);
                            $subcategories = $categoryObj->getChildrenCategories();
                            $categories = [];
                            $index = 0;
                            if($subcategories) {
                                foreach($subcategories as $_subcategory) {
                                    $categories[$_subcategory->getId()] = $index++;
                                }
                            }

                            $_value = serialize($categories);
                        }

                        $this->_mobiadmin3AppsettingFactory->create()->setData([
                            'app_code'     => $data['app_code'],
                            'storeid'      => $store,
                            'setting_code' => $data['setting_code'],
                            'value'        => $_value,
                            ])->save();
                    }
                }
            }

            //$this->_mobiadmin3Applications->setDefaultWidgetData($data['app_code'], null, );
        }
    }
}
