<?php

namespace Mobicommerce\Mobiadmin3\Model;

class Pushhistory extends \Magento\Framework\Model\AbstractModel
{
	protected function _construct()
	{
		$this->_init('Mobicommerce\Mobiadmin3\Model\ResourceModel\Pushhistory');
	}
}